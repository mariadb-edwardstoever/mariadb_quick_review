#!/usr/bin/env bash

# DO NOT EDIT THIS SCRIPT
SCRIPT_VERSION='1.0.5'
declare -a COMPATIBLE=("IMP.0.3" "IMP.0.2")
